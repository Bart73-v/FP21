module RLE where

import Data.List
--Daan Eijkman
--Bart Veldman

-- encodeRLE :: (Eq a) => [a] -> [(a,Int)]
-- decodeRLE :: (Eq a) => [(a,Int)] -> [a]
