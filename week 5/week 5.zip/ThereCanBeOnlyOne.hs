module ThereCanBeOnlyOne where
--Daan Eijkman
--Bart Veldman

-- onlyElem :: (Eq a) => a -> [a] -> Bool

-- onlyOnce :: (a -> Bool) -> [a] -> Bool
