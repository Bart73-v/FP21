module ListHOF where

import Data.List
import Data.Char
import Data.Function
--Daan Eijkman
--Bart Veldman

--sortLength :: [String] -> [String]

--letterClump :: String -> [String]

-- note: test this with 'take 20 fibs'
--fibs :: [Integer]

--zipWith' :: (a -> b -> c) -> [a] -> [b] -> [c]
