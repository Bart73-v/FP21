module OrdList where

import Data.List

--newtype OrdList a = OrdList ...
--  deriving (Eq,Ord,Show)

--instance (Ord a) => Semigroup (OrdList a) where
--  ...

--instance (Ord a) => Monoid (OrdList a) where
--  ...
