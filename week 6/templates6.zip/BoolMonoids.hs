module Monoids where
import Data.Monoid

--newtype ... = ...

--instance Semigroup ... where

--instance Monoid ... where
