module FindDefs where

--Daan Eijkman
--Bart Veldman

--(?$) :: Maybe (a -> b) -> Maybe a -> Maybe b
--(?$) = <*>

--product :: (Applicative t) => t a -> t b -> t (a,b)
--
--apply :: [a -> b] -> a -> [b]

--apply2nd :: [a -> b -> c] -> b -> [a -> c]
